const express = require('express');
const router = express.Router();

const conn = require('../database');

router.get('/select/1',(req,res)=> {
    conn.query('select Nick from usuarios natural join Resena where Evaluacion = 3 and id_usuario >= 6',(err,resp,campos)=>{
        if(!err){
            res.json(resp);
        }else{
            console.log(err);
        }
    });
});
router.get('/select/1',(req,res)=> {
    conn.query('select  nombre,telefono,email from administrador natural join pagina where tipo_de_contenido = "Reseñas"',(err,resp,campos)=>{
        if(!err){
            res.json(resp);
        }else{
            console.log(err);
        }
    });
});
router.get('/select/2',(req,res)=> {
    conn.query('select Nombre from contenido_pag where (Fecha_estreno BETWEEN "1996-01-01" and "2005-01-01") AND TIPO_CATEGORIA = 1',(err,resp,campos)=>{
        if(!err){
            res.json(resp);
        }else{
            console.log(err);
        }
    });
});


module.exports = router;
