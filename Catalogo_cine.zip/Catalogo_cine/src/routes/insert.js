const express = require('express');
const router = express.Router();

const conn = require('../database');

router.post('/insert/1',(req,res)=> {
    conn.query('insert into administrador(nombre,Telefono,Email) values ("Celso cisternas","958431293","Celsitodelflow@email.com")',(err,resp,campos)=>{
        if(!err){
            res.json({status: "Contenido Insertado" });
        }else{
            console.log(err);
        }
    });
});
router.post('/insert/2',(req,res)=> {
    conn.query('insert into usuarios(Nombre,Contraseña) values ("uwus","Celsito")',(err,resp,campos)=>{
        if(!err){
            res.json({status: "Contenido Insertado" });
        }else{
            console.log(err);
        }
    });
});
router.post('/insert/3',(req,res)=> {
    conn.query('insert into contenido_pag (Nombre,Director,Genero,Fecha_estreno,Tipo_categoria) values("Infinity war","Joe russo-Anthony Russo","Ciencia Ficcion","2018-04-23",1)',(err,resp,campos)=>{
        if(!err){
            res.json({status: "Contenido Insertado" });
        }else{
            console.log(err);
        }
    });
});


module.exports = router;