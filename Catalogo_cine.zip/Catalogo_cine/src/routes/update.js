const express = require('express');
const router = express.Router();

const conn = require('../database');

router.put('/update/1',(req,res)=> {
    conn.query('UPDATE contenido_pag SET genero = "Ciencia Ficcion" WHERE nombre= "Stars wars" ',(err,resp,campos)=>{
        if(!err){
            res.json({status: "Contenido Actualizado" });
        }else{
            console.log(err);
        }
    });
});
router.put('/update/2',(req,res)=> {
    conn.query('UPDATE contenido_pag SET genero = "Infantil" WHERE genero="Animacion" and genero = "animacion"',(err,resp,campos)=>{
        if(!err){
            res.json({status: "Contenido Actualizado" });
        }else{
            console.log(err);
        }
    });
});


module.exports = router;
