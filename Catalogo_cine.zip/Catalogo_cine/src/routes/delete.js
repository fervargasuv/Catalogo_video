const express = require('express');
const router = express.Router();

const conn = require('../database');

router.delete('/delete/1',(req,res)=> {
    conn.query('DELETE FROM resena WHERE evaluacion = 1',(err,resp,campos)=>{
        if(!err){
            res.json({status: "Borrado exitosamente"});
        }else{
            console.log(err);
        }
    });
});
router.delete('/delete/2',(req,res)=> {
    conn.query('DELETE FROM contenido_pag WHERE Genero = "accion"',(err,resp,campos)=>{
        if(!err){
            res.json({status: "Borrado exitosamente"});
        }else{
            console.log(err);
        }
    });
});



module.exports = router;