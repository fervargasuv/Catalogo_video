const express = require('express');
const app = express();

//config

app.set('port',process.env.PORT || 3000);
//Middleware
app.use(express.json());//hacerlo JSON

// rutas
app.use(require('./routes/select.js'));
app.use(require('./routes/update.js'));
app.use(require('./routes/delete.js'));
app.use(require('./routes/alter.js'));
app.use(require('./routes/insert.js'));
app.use(require('./routes/drop.js'));


app.listen(app.get('port'),()=> {
    console.log('Servidor en puerto' ,app.get('port'))
});